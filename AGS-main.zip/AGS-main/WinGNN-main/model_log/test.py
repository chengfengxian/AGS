import dgl

print(dgl.__version__)