import os
os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'
import tqdm
import torch
import dgl
import random
import wandb
import math
import time
import numpy as np
from copy import deepcopy
from model.loss import prediction, Link_loss_meta
from model.utils import report_rank_based_eval_meta

def train(args, model, optimizer, device, graph_l, logger, n):
    # 将模型迁移到指定设备
    model.to(device)

    best_param = {'best_mrr': 0, 'best_state': None, 'best_s_dw': None}
    earl_stop_c = 0  # 早停计数
    epoch_count = 0

    # 初始化全局EMA梯度张量
    global_gradient = [torch.zeros_like(p, device=device) for p in model.parameters()]

    for epoch in range(args.epochs):
        # 在每个 epoch 开始时重置 global_gradient
        global_gradient = [torch.zeros_like(p, device=device) for p in model.parameters()]
        # 每个 epoch 设置新的随机种子，确保数据和负采样顺序不同
        random.seed(epoch)
        torch.manual_seed(epoch)
        np.random.seed(epoch)



        # 在每个 epoch 开始时对时间步的图数据随机打乱
        random.shuffle(graph_l)

        total_loss = torch.tensor(0.0, device=device)  # 累积损失初始化
        all_mrr = 0.0  # 累积MRR初始化

        # 初始化模型参数快照（快速权重）和EMA平滑张量
        fast_weights = [p.clone().detach().to(device).requires_grad_(True) for p in model.parameters()]
        S_dw = [torch.zeros_like(p, device=device) for p in fast_weights]

        for t in range(n):  # 按时间步顺序处理快照
            graph = graph_l[t].to(device)
            features = graph.node_feature.to(device)
            graph.edge_label = graph.edge_label.to(device)

            pred = model(graph, features, fast_weights)

            loss = Link_loss_meta(pred, graph.edge_label)

            grad = torch.autograd.grad(loss, fast_weights, retain_graph=True)
            beta = args.beta

            S_dw = list(map(lambda p: beta * p[1] + (1 - beta) * p[0].pow(2), zip(grad, S_dw)))
            local_gradient = list(map(lambda p: p[0] / (torch.sqrt(p[1]) + 1e-8), zip(grad, S_dw)))

            global_gradient = list(map(lambda g, v: g + v, global_gradient, local_gradient))

            w = args.weight_param
            combined_gradient = list(map(
                lambda l, g: w * l + (1 - w) * g / (epoch_count + 1),
                local_gradient, global_gradient
            ))

            fast_weights = list(map(lambda p, cg: p - args.maml_lr * cg, fast_weights, combined_gradient))

            # 打印每个时间步的损失和梯度大小
            # print(
            #     f"Epoch {epoch}, Step {t}, Loss: {loss.item()}, Gradient Mean: {torch.mean(torch.stack([g.mean() for g in grad]))}")

            mrr, *_ = report_rank_based_eval_meta(model, graph, features, fast_weights)
            all_mrr += mrr
            total_loss = total_loss + loss  # 避免 in-place 操作


        avg_mrr = all_mrr / n
        optimizer.zero_grad()
        total_loss.backward()
        optimizer.step()

        # # train 函数中的 optimizer.step() 之后
        # with torch.no_grad():
        #     for param in model.parameters():
        #         print(f"Parameter mean after update: {param.mean()}")

        # # 检查更新后的权重

        mrr, *_ = report_rank_based_eval_meta(model, graph, features, fast_weights)
        acc, ap, f1, macro_auc, micro_auc = prediction(pred, graph.edge_label)
        logger.info(
            f"meta epoch:{epoch}, mrr:{avg_mrr:.5f}, loss:{total_loss.item():.5f}, acc:{acc:.5f}, ap:{ap:.5f}, f1:{f1:.5f}, macro_auc:{macro_auc:.5f}, micro_auc:{micro_auc:.5f}")

        epoch_count += 1
        # # 日志记录
        # logger.info(f'Epoch {epoch}, MRR: {avg_mrr:.5f}')\



        # 更新最佳模型状态
        if avg_mrr > best_param['best_mrr']:
            best_param = {'best_mrr': avg_mrr, 'best_state': deepcopy(model.state_dict()), 'best_s_dw': S_dw}
            earl_stop_c = 0  # 重置早停计数
        else:
            earl_stop_c += 1
            if earl_stop_c == 10:  # 触发早停机制
                break




        # # 日志记录当前epoch的MRR
        # logger.info(f'Epoch {epoch}, MRR: {avg_mrr:.5f}')
            # 在每个 epoch 结束时记录完整的指标
            # 计算 MRR 和其他指标


        # train 函数中的 for epoch in range(args.epochs) 循环结束时：
        with torch.no_grad():
            for param, fast_weight in zip(model.parameters(), fast_weights):
                param.copy_(fast_weight)



    return best_param

