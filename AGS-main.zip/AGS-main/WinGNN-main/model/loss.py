#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Description :
import os
os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import torchmetrics
from model.config import cfg
from sklearn.metrics import average_precision_score
from sklearn.metrics import f1_score, accuracy_score
from sklearn.metrics import roc_auc_score

def prediction(pred_score, true_l):
    # Acc_torch = torchmetrics.Accuracy(task='binary').to(pred_score)
    # Macro_Auc_torch = torchmetrics.AUROC(task='binary', average='macro').to(pred_score)
    # Micro_Auc_torch = torchmetrics.AUROC(task='binary', average='micro').to(pred_score)
    # Ap_torch = torchmetrics.AveragePrecision(task='binary').to(pred_score)
    # F1_torch = torchmetrics.F1Score(task='binary', average='macro').to(pred_score)
    #
    # acc_torch = Acc_torch(pred_score, true_l.to(pred_score))
    # macro_auc_torch = Macro_Auc_torch(pred_score, true_l.to(pred_score))
    # micro_auc_torch = Micro_Auc_torch(pred_score, true_l.to(pred_score))
    # ap_torch = Ap_torch(pred_score, true_l.to(pred_score))
    # f1_torch = F1_torch(pred_score, true_l.to(pred_score))

    # 确保 pred_score 是一个一维张量
    pred_score = pred_score.view(-1)
    true_l = true_l.view(-1)
    if pred_score.shape[0] != true_l.shape[0]:
        min_len = min(pred_score.shape[0], true_l.shape[0])
        pred_score = pred_score[:min_len]
        true_l = true_l[:min_len]

    pred_binary = torch.where(pred_score > 0.5, 1, 0).detach().cpu().numpy()
    true_l = true_l.detach().cpu().numpy()
    pred_score = pred_score.detach().cpu().numpy()

    acc = accuracy_score(true_l, pred_binary)
    ap = average_precision_score(true_l, pred_score)
    f1 = f1_score(true_l, pred_binary, average='macro')
    macro_auc = roc_auc_score(true_l, pred_score, average='macro')
    micro_auc = roc_auc_score(true_l, pred_score, average='micro')

    return acc, ap, f1, macro_auc, micro_auc


def Link_loss_meta(pred, y):
    L = nn.BCELoss()
    pred = pred.float()
    y = y.to(pred)
    loss = L(pred, y)

    return loss

