#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Description :

import os
os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'
import numpy as np
import torch
from copy import deepcopy
from model.loss import prediction, Link_loss_meta
from model.utils import report_rank_based_eval_meta


def test(graph_l, model, args, logger, n, S_dw, device):
    model.eval()
    model.to(device)

    beta = args.beta  # EMA平滑系数
    avg_mrr = 0.0
    avg_auc = 0.0
    avg_acc = 0.0

    # 初始化全局EMA梯度
    global_gradient = [torch.zeros_like(p, device=device) for p in model.parameters()]

    # 初始化模型参数快照，并确保启用梯度追踪
    fast_weights = [p.clone().detach().to(device).requires_grad_(True) for p in model.parameters()]
    S_dw = [torch.zeros_like(p, device=device) for p in fast_weights]

    for t in range(n, len(graph_l)):
        graph = graph_l[t].to(device)
        features = graph.node_feature.to(device)
        graph.edge_label = graph.edge_label.to(device)

        # 前向传播
        pred = model(graph, features, fast_weights)

        # 将预测值和真实标签对齐
        pred = pred.view(-1)
        if pred.shape[0] != graph.edge_label.shape[0]:
            min_len = min(pred.shape[0], graph.edge_label.shape[0])
            pred = pred[:min_len]
            graph.edge_label = graph.edge_label[:min_len]


        loss = Link_loss_meta(pred, graph.edge_label)

        with torch.enable_grad():
            # 计算局部 EMA 梯度更新
            grad = torch.autograd.grad(loss, fast_weights, create_graph=False)
            S_dw = list(map(lambda p: beta * p[1] + (1 - beta) * p[0].pow(2), zip(grad, S_dw)))
            local_gradient = list(map(lambda p: p[0] / (torch.sqrt(p[1]) + 1e-8), zip(grad, S_dw)))

            # 累加全局 EMA 梯度
            global_gradient = list(map(lambda g, v: g + v, global_gradient, local_gradient))

            # 组合局部和全局梯度更新
            w = args.weight_param
            combined_gradient = list(map(
                lambda l, g: w * l + (1 - w) * g / (t - n + 1),
                local_gradient, global_gradient
            ))

            fast_weights = [p - args.maml_lr * cg for p, cg in zip(fast_weights, combined_gradient)]

        # 计算 MRR 和其他指标
        mrr, *_ = report_rank_based_eval_meta(model, graph, features, fast_weights)
        acc, ap, f1, macro_auc, micro_auc = prediction(pred, graph.edge_label)

        avg_mrr += mrr
        avg_auc += macro_auc
        avg_acc += acc

        logger.info(f'Test MRR: {mrr:.5f}, AUC: {macro_auc:.5f}, Acc: {acc:.5f}, AP: {ap:.5f}, '
                    f'F1: {f1:.5f}, Macro AUC: {macro_auc:.5f}, Micro AUC: {micro_auc:.5f}')

    num_test_steps = len(graph_l) - n
    avg_mrr /= num_test_steps
    avg_auc /= num_test_steps
    avg_acc /= num_test_steps

    logger.info({'avg_acc': avg_acc, 'avg_auc': avg_auc, 'avg_mrr': avg_mrr, })

    return avg_mrr

